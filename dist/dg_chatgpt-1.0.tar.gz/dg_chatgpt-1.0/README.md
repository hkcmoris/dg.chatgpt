# DevGround ChatGPT API wrapper

This is a wrapper for the [ChatGPT API](https://platform.openai.com/docs/introduction) by [DevGround](https://devground.cz/).
-model: gpt-3.5-turbo

requires environment variables:

- OPENAI_API_KEY
